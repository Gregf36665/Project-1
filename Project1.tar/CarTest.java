import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class CarTest extends TestCase {
  
  /**
   * A test method.
   * (Replace "X" with a name describing the test.  You may write as
   * many "testSomething" methods in this class as you wish, and each
   * one will be called when running JUnit over this class.)
   */
  public void testInvalidFuel(){
    try{
    Car c = new Car(2);
    c.getFuel();
    fail("Missing exception");
    }
    catch (Exception e){
    }
  }
  
}
